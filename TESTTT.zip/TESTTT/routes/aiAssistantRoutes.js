"use strict";

const express = require("express");
const { explain } = require("../controllers/aiAssistantController");

const router = express.Router();
router.post("/explain", explain);

module.exports = router;
