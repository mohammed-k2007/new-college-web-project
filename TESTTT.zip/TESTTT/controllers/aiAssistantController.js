"use strict";

const { createHash } = require("node:crypto");
const pool = require("../db/pool");
const { generateCodeExplanation } = require("../services/geminiService");

const VALID_PROMPT_TYPES = new Set([
  "explain_line",
  "why_var_changed",
  "loop_logic",
  "loop_exit",
  "memory_overview",
  "code_overview",
  "condition_logic",
  "operator_explanation",
  "function_call",
  "return_behavior",
  "custom_question"
]);

function isPositiveInteger(value) {
  return Number.isSafeInteger(value) && value > 0 && value <= 2147483647;
}

function validateRequest(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)) return "A JSON request body is required.";
  if (!isPositiveInteger(body.lessonId)) return "lessonId must be a positive integer.";
  if (!isPositiveInteger(body.lineNumber)) return "lineNumber must be a positive integer.";
  if (typeof body.codeSnippet !== "string" || !body.codeSnippet.trim() || body.codeSnippet.length > 4000) {
    return "codeSnippet must contain 1–4,000 characters.";
  }
  if (typeof body.promptType !== "string" || !VALID_PROMPT_TYPES.has(body.promptType)) {
    return "promptType must be a supported assistant question type.";
  }
  if (typeof body.userQuestion !== "string" || !body.userQuestion.trim() || body.userQuestion.length > 240) {
    return "userQuestion must contain 1–240 characters.";
  }
  if (!body.currentVariables || typeof body.currentVariables !== "object" || Array.isArray(body.currentVariables)) {
    return "currentVariables must be a JSON object.";
  }
  if (Object.keys(body.currentVariables).length > 40) return "currentVariables may contain at most 40 entries.";
  if (Buffer.byteLength(JSON.stringify(body.currentVariables), "utf8") > 6000) {
    return "currentVariables must be no larger than 6,000 bytes.";
  }
  return null;
}

function buildLockName(lessonId, lineNumber, promptType) {
  const cacheKey = `${lessonId}:${lineNumber}:${promptType}`;
  const digest = createHash("sha256").update(cacheKey).digest("hex").slice(0, 60);
  return `ai:${digest}`;
}

async function explain(req, res) {
  const validationError = validateRequest(req.body);
  if (validationError) {
    return res.status(400).json({ success: false, error: validationError });
  }

  const {
    lessonId,
    lineNumber,
    codeSnippet,
    promptType,
    currentVariables,
    userQuestion
  } = req.body;
  const cachePromptType = promptType === "custom_question"
    ? `custom_${createHash("sha256").update(userQuestion.trim().toLowerCase()).digest("hex").slice(0, 32)}`
    : promptType;

  let connection;
  let lockAcquired = false;
  let lockName;

  try {
    connection = await pool.getConnection();
    lockName = buildLockName(lessonId, lineNumber, cachePromptType);
    const [lockRows] = await connection.query("SELECT GET_LOCK(?, 10) AS acquired", [lockName]);
    lockAcquired = lockRows[0]?.acquired === 1;
    if (!lockAcquired) {
      return res.status(503).json({
        success: false,
        error: "This explanation is busy right now. Please try again in a moment."
      });
    }

    const [rows] = await connection.execute(
      `SELECT code_snippet, ai_response_text
       FROM smart_ai_explanations
       WHERE lesson_id = ? AND line_number = ? AND prompt_type = ?
       LIMIT 1`,
      [lessonId, lineNumber, cachePromptType]
    );
    const cached = rows[0];
    if (cached && cached.code_snippet === codeSnippet) {
      return res.json({
        success: true,
        source: "cache",
        explanation: cached.ai_response_text
      });
    }

    const explanation = await generateCodeExplanation({
      codeSnippet,
      lineNumber,
      currentVariables,
      userQuestion: userQuestion.trim()
    });

    await connection.execute(
      `INSERT INTO smart_ai_explanations
         (lesson_id, line_number, code_snippet, prompt_type, ai_response_text)
       VALUES (?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         code_snippet = VALUES(code_snippet),
         ai_response_text = VALUES(ai_response_text),
         created_at = CURRENT_TIMESTAMP`,
      [lessonId, lineNumber, codeSnippet, cachePromptType, explanation]
    );

    return res.json({ success: true, source: "gemini", explanation });
  } catch (error) {
    console.error("Smart assistant request failed:", error.message);
    return res.status(502).json({
      success: false,
      error: "The AI tutor is unavailable right now. Please try again shortly."
    });
  } finally {
    if (connection) {
      if (lockAcquired) {
        try {
          await connection.query("SELECT RELEASE_LOCK(?)", [lockName]);
        } catch (error) {
          console.error("Could not release Smart Assistant cache lock:", error.message);
        }
      }
      connection.release();
    }
  }
}

module.exports = { explain };
