CREATE TABLE IF NOT EXISTS smart_ai_explanations (
  explanation_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  lesson_id INT UNSIGNED NOT NULL,
  line_number INT UNSIGNED NOT NULL,
  code_snippet TEXT NOT NULL,
  prompt_type VARCHAR(40) NOT NULL,
  ai_response_text TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (explanation_id),
  UNIQUE KEY uq_smart_ai_explanation_lesson_line_type (lesson_id, line_number, prompt_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
