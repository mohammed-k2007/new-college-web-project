"use strict";

require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("node:path");
const assistantRoutes = require("./routes/aiAssistantRoutes");

const app = express();
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || "127.0.0.1";

app.disable("x-powered-by");
if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://cdn.jsdelivr.net"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "16kb", strict: true }));

const assistantLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 30,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: {
    success: false,
    error: "Too many tutor requests. Please wait a moment and try again."
  }
});

app.use("/api/v1/assistant", assistantLimiter, assistantRoutes);

app.get("/", (req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.get("/index.html", (req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.get("/style.css", (req, res) => res.sendFile(path.join(__dirname, "style.css")));
app.get("/script.js", (req, res) => res.sendFile(path.join(__dirname, "script.js")));

app.use("/api", (req, res) => {
  res.status(404).json({ success: false, error: "API endpoint not found." });
});
app.use((req, res) => res.status(404).type("text").send("Not found."));
app.use((error, req, res, next) => {
  console.error("Express request failed:", error.message);
  if (res.headersSent) return next(error);
  const status = error.status === 413 ? 413 : 400;
  return res.status(status).json({
    success: false,
    error: status === 413 ? "Request body is too large." : "Request could not be processed."
  });
});

app.listen(port, host, () => {
  console.log(`Visual Coder Assistant listening on http://${host}:${port}`);
});
