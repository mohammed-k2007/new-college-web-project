const lessons = {
  variables: {
    title: "Variables",
    code: [
      "// Keep track of a student's progress",
      "let score = 0;",
      "let bonus = 5;",
      "score = score + bonus;",
      "let message = \"Nice work!\";",
      "score = score + 2;",
      "let passed = score >= 7;",
      "console.log(message, score);"
    ],
    steps: [
      { line: 1, vars: {}, message: "A comment is a note for people reading the code. JavaScript skips it." },
      { line: 2, vars: { score: 0 }, message: "We create a variable named <strong>score</strong> and give it the starting value 0." },
      { line: 3, vars: { score: 0, bonus: 5 }, message: "<strong>bonus</strong> stores 5. Each variable keeps its own value in memory." },
      { line: 4, vars: { score: 5, bonus: 5 }, message: "We add <strong>bonus</strong> to <strong>score</strong>. The result, 5, replaces the old score." },
      { line: 5, vars: { score: 5, bonus: 5, message: "Nice work!" }, message: "The text in quotes is a string. We save it in the variable <strong>message</strong>." },
      { line: 6, vars: { score: 7, bonus: 5, message: "Nice work!" }, message: "Another addition updates <strong>score</strong> from 5 to 7. Watch its card flash red." },
      { line: 7, vars: { score: 7, bonus: 5, message: "Nice work!", passed: true }, message: "The comparison checks whether <strong>score</strong> is at least 7. Its result is true." },
      { line: 8, vars: { score: 7, bonus: 5, message: "Nice work!", passed: true }, message: "We send the message and score to the console. The stored values stay in memory.", output: "Nice work! 7" }
    ]
  },
  loops: {
    title: "Loops",
    code: [
      "// Add up the numbers from 1 to 3",
      "let sum = 0;",
      "for (let i = 1; i <= 3; i++) {",
      "  sum = sum + i;",
      "}",
      "console.log(sum);"
    ],
    steps: [
      { line: 1, vars: {}, message: "This comment describes our goal. It does not execute." },
      { line: 2, vars: { sum: 0 }, message: "We start with a <strong>sum</strong> of 0. The loop will add each number to it." },
      { line: 3, vars: { sum: 0, i: 1 }, message: "The loop starts at <strong>i = 1</strong>. Since 1 is at most 3, its body will run." },
      { line: 4, vars: { sum: 1, i: 1 }, message: "First pass: add <strong>i (1)</strong> to sum. Now sum is 1." },
      { line: 3, vars: { sum: 1, i: 2 }, message: "The loop increments <strong>i</strong> to 2, checks the condition, and continues." },
      { line: 4, vars: { sum: 3, i: 2 }, message: "Second pass: add <strong>2</strong> to the running sum. Now it is 3." },
      { line: 3, vars: { sum: 3, i: 3 }, message: "<strong>i</strong> becomes 3. It still meets the loop condition, so one more pass." },
      { line: 4, vars: { sum: 6, i: 3 }, message: "Third pass: add <strong>3</strong>. The total is now 6." },
      { line: 3, vars: { sum: 6, i: 4 }, message: "<strong>i</strong> becomes 4. It is greater than 3, so the loop finishes." },
      { line: 6, vars: { sum: 6, i: 4 }, message: "The loop is done. We log the final sum: <strong>6</strong>.", output: "6" }
    ]
  },
  conditions: {
    title: "Conditions",
    code: [
      "// Decide whether to bring a jacket",
      "let temperature = 14;",
      "let raining = true;",
      "let bringJacket = false;",
      "if (temperature < 18 || raining) {",
      "  bringJacket = true;",
      "}",
      "console.log(bringJacket);"
    ],
    steps: [
      { line: 1, vars: {}, message: "This comment explains the decision our program is about to make." },
      { line: 2, vars: { temperature: 14 }, message: "<strong>temperature</strong> stores today's temperature: 14 degrees." },
      { line: 3, vars: { temperature: 14, raining: true }, message: "<strong>raining</strong> stores a Boolean value: true or false." },
      { line: 4, vars: { temperature: 14, raining: true, bringJacket: false }, message: "We begin by assuming <strong>bringJacket</strong> is false." },
      { line: 5, vars: { temperature: 14, raining: true, bringJacket: false }, message: "14 is below 18, so the first check is true. <strong>||</strong> means either check can pass." },
      { line: 6, vars: { temperature: 14, raining: true, bringJacket: true }, message: "Because the condition passed, this block runs and changes <strong>bringJacket</strong> to true." },
      { line: 8, vars: { temperature: 14, raining: true, bringJacket: true }, message: "We print the result: <strong>true</strong>. A jacket is a good idea!", output: "true" }
    ]
  },
  functions: {
    title: "Functions",
    code: [
      "// Reuse a little calculation",
      "function double(number) {",
      "  return number * 2;",
      "}",
      "let startingValue = 4;",
      "let result = double(startingValue);",
      "console.log(result);"
    ],
    steps: [
      { line: 1, vars: {}, message: "This comment tells us the function will help us reuse a calculation." },
      { line: 2, vars: {}, message: "We define a function called <strong>double</strong>. Defining it does not run its body yet." },
      { line: 3, vars: {}, message: "The function body returns its input multiplied by 2 whenever it is called." },
      { line: 4, vars: {}, message: "The closing brace finishes the function definition. It is ready to use." },
      { line: 5, vars: { startingValue: 4 }, message: "<strong>startingValue</strong> stores the number 4, which we will pass into our function." },
      { line: 6, vars: { startingValue: 4, number: 4, result: 8 }, message: "We call <strong>double(4)</strong>. Inside the function, 4 × 2 returns 8 into result." },
      { line: 7, vars: { startingValue: 4, result: 8 }, message: "The function has finished. We log its returned value: <strong>8</strong>.", output: "8" }
    ]
  }
};

const elements = {
  codeList: document.querySelector("#code-list"),
  codeScroll: document.querySelector("#code-scroll"),
  codeInput: document.querySelector("#code-input"),
  fileName: document.querySelector("#file-name"),
  fileLocation: document.querySelector("#file-location"),
  runCode: document.querySelector("#run-code"),
  variableGrid: document.querySelector("#variable-grid"),
  memoryCount: document.querySelector("#memory-count"),
  logicMessage: document.querySelector("#logic-message"),
  linePosition: document.querySelector("#line-position"),
  consoleOutput: document.querySelector("#console-output"),
  consoleState: document.querySelector("#console-state"),
  stepCurrent: document.querySelector("#step-current"),
  stepTotal: document.querySelector("#step-total"),
  progressBar: document.querySelector("#progress-bar"),
  progressLabel: document.querySelector("#progress-label"),
  previous: document.querySelector("#previous-step"),
  next: document.querySelector("#next-step"),
  play: document.querySelector("#play-button"),
  stop: document.querySelector("#stop-reset"),
  resetCode: document.querySelector("#reset-code"),
  speed: document.querySelector("#speed-slider"),
  topicButtons: [...document.querySelectorAll(".topic-button")],
  assistantOrb: document.querySelector("#assistant-orb"),
  assistantPopover: document.querySelector("#assistant-popover"),
  assistantContent: document.querySelector("#assistant-content"),
  assistantTitle: document.querySelector("#assistant-title"),
  assistantClose: document.querySelector("#close-assistant")
};

let activeTopic = "variables";
let stepIndex = 0;
let playTimer = null;
let previousValues = {};
let assistantView = "suggestions";
let customLesson = null;
let editorDirty = false;

function getCurrentLesson() {
  return customLesson || lessons[activeTopic];
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function colorize(line) {
  const tokenPattern = /(\/\/.*$)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|\b(let|const|var|for|if|function|return|true|false)\b|\b(console|log|double)\b|\b(\d+)\b/g;
  let html = "";
  let cursor = 0;
  for (const match of line.matchAll(tokenPattern)) {
    html += escapeHtml(line.slice(cursor, match.index));
    const className = match[1] ? "token-comment" : match[2] ? "token-string" : match[3] ? "token-keyword" : match[4] ? "token-function" : "token-number";
    html += `<span class="${className}">${escapeHtml(match[0])}</span>`;
    cursor = match.index + match[0].length;
  }
  html += escapeHtml(line.slice(cursor));
  return html || "&nbsp;";
}

function tokenizeExpression(expression, lineNumber) {
  const pattern = /\s*(===|!==|==|!=|<=|>=|&&|\|\||\+=|-=|\*=|\/=|\+\+|--|(?:\d+\.?\d*|\.\d+)|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[A-Za-z_$][\w$]*|[()+\-*/%<>=!])/gy;
  const tokens = [];
  let position = 0;
  while (position < expression.length) {
    pattern.lastIndex = position;
    const match = pattern.exec(expression);
    if (!match) {
      if (!expression.slice(position).trim()) break;
      throw new Error(`Line ${lineNumber}: unsupported expression near "${expression.slice(position).trim()}".`);
    }
    tokens.push(match[1]);
    position = pattern.lastIndex;
  }
  return tokens;
}

function evaluateExpression(expression, variables, lineNumber) {
  const tokens = tokenizeExpression(expression, lineNumber);
  let position = 0;
  const precedence = { "||": 1, "&&": 2, "==": 3, "===": 3, "!=": 3, "!==": 3, "<": 4, "<=": 4, ">": 4, ">=": 4, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6 };

  function primary() {
    const token = tokens[position++];
    if (token === undefined) throw new Error(`Line ${lineNumber}: expected a value.`);
    if (token === "(") {
      const value = expressionAt(0);
      if (tokens[position++] !== ")") throw new Error(`Line ${lineNumber}: expected a closing parenthesis.`);
      return value;
    }
    if (token === "!" || token === "-" || token === "+") {
      const value = primary();
      if (token === "!") return !value;
      if (typeof value !== "number") throw new Error(`Line ${lineNumber}: unary ${token} requires a number.`);
      return token === "-" ? -value : value;
    }
    if (/^(?:\d+\.?\d*|\.\d+)$/.test(token)) return Number(token);
    if (token[0] === '"' || token[0] === "'") {
      if (token[0] === '"') return JSON.parse(token);
      return token.slice(1, -1).replace(/\\n/g, "\n").replace(/\\'/g, "'").replace(/\\\\/g, "\\");
    }
    if (token === "true") return true;
    if (token === "false") return false;
    if (/^[A-Za-z_$][\w$]*$/.test(token)) {
      if (!Object.prototype.hasOwnProperty.call(variables, token)) throw new Error(`Line ${lineNumber}: "${token}" has not been declared.`);
      return variables[token];
    }
    throw new Error(`Line ${lineNumber}: unexpected "${token}".`);
  }

  function expressionAt(minimumPrecedence) {
    let left = primary();
    while (position < tokens.length) {
      const operator = tokens[position];
      const operatorPrecedence = precedence[operator];
      if (operatorPrecedence === undefined || operatorPrecedence < minimumPrecedence) break;
      position += 1;
      const right = expressionAt(operatorPrecedence + 1);
      switch (operator) {
        case "||": left = Boolean(left || right); break;
        case "&&": left = Boolean(left && right); break;
        case "==":
        case "===": left = left === right; break;
        case "!=":
        case "!==": left = left !== right; break;
        case "<": left = left < right; break;
        case "<=": left = left <= right; break;
        case ">": left = left > right; break;
        case ">=": left = left >= right; break;
        case "+": left = typeof left === "string" || typeof right === "string" ? String(left) + String(right) : left + right; break;
        case "-": left = left - right; break;
        case "*": left = left * right; break;
        case "/": left = left / right; break;
        case "%": left = left % right; break;
        default: throw new Error(`Line ${lineNumber}: unsupported operator "${operator}".`);
      }
    }
    return left;
  }

  const result = expressionAt(0);
  if (position !== tokens.length) throw new Error(`Line ${lineNumber}: unexpected "${tokens[position]}".`);
  return result;
}

function splitArguments(source, delimiter) {
  const parts = [];
  let start = 0;
  let depth = 0;
  let quote = "";
  let escaped = false;
  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];
    if (quote) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === quote) quote = "";
    } else if (character === '"' || character === "'") quote = character;
    else if (character === "(") depth += 1;
    else if (character === ")") depth -= 1;
    else if (character === delimiter && depth === 0) {
      parts.push(source.slice(start, index).trim());
      start = index + 1;
    }
  }
  parts.push(source.slice(start).trim());
  return parts;
}

function parseCustomProgram(lines) {
  function parseStatements(start, nested) {
    const statements = [];
    let index = start;
    while (index < lines.length) {
      const source = lines[index].trim();
      const line = index + 1;
      if (source === "}") {
        if (!nested) throw new Error(`Line ${line}: unexpected closing brace.`);
        return { statements, next: index + 1 };
      }
      if (!source) {
        index += 1;
        continue;
      }
      if (source.startsWith("//")) {
        statements.push({ type: "comment", line });
        index += 1;
        continue;
      }
      const conditional = source.match(/^if\s*\((.*)\)\s*\{\s*$/);
      const loop = source.match(/^for\s*\((.*)\)\s*\{\s*$/);
      if (conditional) {
        const consequent = parseStatements(index + 1, true);
        index = consequent.next;
        let alternate = [];
        if (lines[index] && lines[index].trim() === "else {") {
          const parsedAlternate = parseStatements(index + 1, true);
          alternate = parsedAlternate.statements;
          index = parsedAlternate.next;
        }
        statements.push({ type: "if", line, condition: conditional[1], consequent: consequent.statements, alternate });
        continue;
      }
      if (loop) {
        const header = splitArguments(loop[1], ";");
        if (header.length !== 3 || header.some(part => !part)) throw new Error(`Line ${line}: a for loop needs an initializer, condition, and update.`);
        const body = parseStatements(index + 1, true);
        statements.push({ type: "for", line, initializer: header[0], condition: header[1], update: header[2], body: body.statements });
        index = body.next;
        continue;
      }
      if (/^(?:if|for)\b/.test(source)) throw new Error(`Line ${line}: use a braced if or for block, with its closing brace on a separate line.`);
      if (/^}/.test(source)) throw new Error(`Line ${line}: unexpected code after a closing brace.`);
      if (/^(?:let|const|var)\b/.test(source)) {
        const declaration = source.match(/^(let|const|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(.+?)\s*;?$/);
        if (!declaration) throw new Error(`Line ${line}: initialize each variable when you declare it.`);
        statements.push({ type: "declare", kind: declaration[1], name: declaration[2], expression: declaration[3], line });
      } else {
        const log = source.match(/^console\.log\((.*)\)\s*;?$/);
        const increment = source.match(/^([A-Za-z_$][\w$]*)\s*(\+\+|--)\s*;?$/);
        const assignment = source.match(/^([A-Za-z_$][\w$]*)\s*(=|\+=|-=|\*=|\/=)\s*(.+?)\s*;?$/);
        if (log) statements.push({ type: "log", expressions: log[1].trim() ? splitArguments(log[1], ",") : [], line });
        else if (increment) statements.push({ type: "increment", name: increment[1], operator: increment[2], line });
        else if (assignment) statements.push({ type: "assign", name: assignment[1], operator: assignment[2], expression: assignment[3], line });
        else throw new Error(`Line ${line}: unsupported statement. Use a variable, assignment, if/for block, or console.log.`);
      }
      index += 1;
    }
    if (nested) throw new Error(`Line ${start}: missing closing brace.`);
    return { statements, next: index };
  }

  return parseStatements(0, false).statements;
}

function executeCustomProgram(source) {
  if (!source.trim()) throw new Error("Enter some JavaScript before running the trace.");
  if (source.length > 5000) throw new Error("Keep the example under 5,000 characters.");
  const lines = source.replace(/\r/g, "").split("\n");
  if (lines.length > 120) throw new Error("Keep the example under 120 lines.");
  const program = parseCustomProgram(lines);
  const variables = {};
  const constants = new Set();
  const steps = [];

  function record(line, message, output) {
    if (steps.length >= 500) throw new Error(`Line ${line}: execution stopped at the 500-step safety limit.`);
    const step = { line, vars: { ...variables }, message };
    if (output !== undefined) step.output = output;
    steps.push(step);
  }

  function executeSimple(statement, recordStep) {
    const line = statement.line;
    if (statement.type === "comment") {
      if (recordStep) record(line, "Comments are notes for people. JavaScript skips them.");
      return;
    }
    if (statement.type === "declare") {
      if (Object.prototype.hasOwnProperty.call(variables, statement.name)) throw new Error(`Line ${line}: "${statement.name}" is already declared.`);
      variables[statement.name] = evaluateExpression(statement.expression, variables, line);
      if (statement.kind === "const") constants.add(statement.name);
      if (recordStep) record(line, `Created ${statement.kind} "${statement.name}" in memory.`);
      return;
    }
    if (statement.type === "assign" || statement.type === "increment") {
      if (!Object.prototype.hasOwnProperty.call(variables, statement.name)) throw new Error(`Line ${line}: "${statement.name}" has not been declared.`);
      if (constants.has(statement.name)) throw new Error(`Line ${line}: "${statement.name}" is a constant and cannot be reassigned.`);
      if (statement.type === "increment") {
        if (typeof variables[statement.name] !== "number") throw new Error(`Line ${line}: increment requires a numeric variable.`);
        variables[statement.name] += statement.operator === "++" ? 1 : -1;
      } else {
        const value = evaluateExpression(statement.expression, variables, line);
        switch (statement.operator) {
          case "=": variables[statement.name] = value; break;
          case "+=": variables[statement.name] += value; break;
          case "-=": variables[statement.name] -= value; break;
          case "*=": variables[statement.name] *= value; break;
          case "/=": variables[statement.name] /= value; break;
          default: throw new Error(`Line ${line}: unsupported assignment operator.`);
        }
      }
      if (recordStep) record(line, `Updated "${statement.name}" in memory.`);
      return;
    }
    if (statement.type === "log") {
      const output = statement.expressions.map(expression => {
        const value = evaluateExpression(expression, variables, line);
        return typeof value === "string" ? value : String(value);
      }).join(" ");
      if (recordStep) record(line, "Wrote the current value to the console.", output);
    }
  }

  function run(statements, depth) {
    if (depth > 20) throw new Error("The program has too many nested blocks.");
    statements.forEach(statement => {
      if (statement.type === "if") {
        const result = Boolean(evaluateExpression(statement.condition, variables, statement.line));
        record(statement.line, `Condition evaluated to ${result}.`);
        run(result ? statement.consequent : statement.alternate, depth + 1);
      } else if (statement.type === "for") {
        const declaration = statement.initializer.match(/^(?:let|const|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(.+?)\s*;?$/);
        const assignment = statement.initializer.match(/^([A-Za-z_$][\w$]*)\s*=\s*(.+?)\s*;?$/);
        if (declaration) executeSimple({ type: "declare", kind: "let", name: declaration[1], expression: declaration[2], line: statement.line }, false);
        else if (assignment) executeSimple({ type: "assign", name: assignment[1], operator: "=", expression: assignment[2], line: statement.line }, false);
        else throw new Error(`Line ${statement.line}: unsupported for-loop initializer.`);
        let iterations = 0;
        while (Boolean(evaluateExpression(statement.condition, variables, statement.line))) {
          if (iterations >= 100) throw new Error(`Line ${statement.line}: loop stopped at the 100-iteration safety limit.`);
          record(statement.line, `Loop condition is true${variables.i !== undefined ? ` (i = ${variables.i})` : ""}.`);
          run(statement.body, depth + 1);
          const update = statement.update.match(/^([A-Za-z_$][\w$]*)\s*(\+\+|--)\s*;?$/);
          if (update) executeSimple({ type: "increment", name: update[1], operator: update[2], line: statement.line }, false);
          else {
            const updateAssignment = statement.update.match(/^([A-Za-z_$][\w$]*)\s*(=|\+=|-=|\*=|\/=)\s*(.+?)\s*;?$/);
            if (!updateAssignment) throw new Error(`Line ${statement.line}: unsupported for-loop update.`);
            executeSimple({ type: "assign", name: updateAssignment[1], operator: updateAssignment[2], expression: updateAssignment[3], line: statement.line }, false);
          }
          iterations += 1;
        }
        record(statement.line, "Loop condition is false. The loop is complete.");
      } else executeSimple(statement, true);
    });
  }

  run(program, 0);
  if (steps.length === 0) throw new Error("Add a statement or comment before running the trace.");
  return { title: "Your code", code: lines, steps };
}

function executeWithJavaScriptInterpreter(source) {
  if (!window.Interpreter) {
    throw new Error("This code needs the JavaScript sandbox. Check your internet connection, then reload the page.");
  }
  if (source.length > 20000) throw new Error("Keep the example under 20,000 characters.");
  let code = source
    .replace(/(^|[;{}\n\r]\s*)(?:let|const)(?=\s+[A-Za-z_$])/g, (match, prefix) => `${prefix}var  `)
    .replace(/(\bfor\s*\(\s*)(?:let|const)(?=\s+[A-Za-z_$])/g, (match, prefix) => `${prefix}var  `);
  if (window.Babel) {
    try {
      code = window.Babel.transform(source, {
        presets: [["env", { targets: { ie: "11" } }]],
        sourceType: "script",
        retainLines: true,
        compact: false
      }).code;
    } catch (error) {
      throw new Error(`JavaScript could not be compiled: ${error.message}`);
    }
  }
  const output = [];
  const formatPseudoValue = (interpreter, value) => {
    if (value === undefined) return "undefined";
    if (value === null || typeof value !== "object") return String(value);
    try {
      const native = interpreter.pseudoToNative(value);
      if (typeof native === "function") return "ƒ function";
      const text = JSON.stringify(native);
      return text === undefined ? "Object" : text.length > 100 ? `${text.slice(0, 97)}…` : text;
    } catch (error) {
      return "Object";
    }
  };
  const variableNames = new Set();
  const functionNames = new Set();
  for (const match of source.matchAll(/\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)/g)) variableNames.add(match[1]);
  for (const match of source.matchAll(/\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g)) {
    variableNames.add(match[1]);
    functionNames.add(match[1]);
  }
  for (const match of source.matchAll(/\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:function\b|(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>)/g)) {
    variableNames.add(match[1]);
    functionNames.add(match[1]);
  }
  for (const match of source.matchAll(/\bfunction(?:\s+[A-Za-z_$][\w$]*)?\s*\(([^)]*)\)/g)) {
    match[1].split(",").forEach(name => {
      const trimmed = name.trim();
      if (/^[A-Za-z_$][\w$]*$/.test(trimmed)) variableNames.add(trimmed);
    });
  }
  for (const match of source.matchAll(/\b([A-Za-z_$][\w$]*)\s*=>/g)) variableNames.add(match[1]);
  for (const match of source.matchAll(/\(([^()]*)\)\s*=>/g)) {
    match[1].split(",").forEach(name => {
      const trimmed = name.trim();
      if (/^[A-Za-z_$][\w$]*$/.test(trimmed)) variableNames.add(trimmed);
    });
  }

  const interpreter = new window.Interpreter(code, (instance, globalObject) => {
    const consoleObject = instance.nativeToPseudo({});
    const log = instance.createNativeFunction(function log() {
      const values = Array.from(arguments).map(value => formatPseudoValue(instance, value));
      output.push(values.join(" "));
    });
    instance.setProperty(consoleObject, "log", log);
    instance.setProperty(globalObject, "console", consoleObject);
  });
  const offsets = [0];
  for (let index = 0; index < code.length; index += 1) {
    if (code[index] === "\n") offsets.push(index + 1);
  }
  const getLine = offset => {
    let low = 0;
    let high = offsets.length;
    while (low < high) {
      const middle = (low + high) >>> 1;
      if (offsets[middle] <= offset) low = middle + 1;
      else high = middle;
    }
    return low;
  };
  let oldStack = [];
  const isLine = stack => {
    if (!stack.length) return false;
    const state = stack[stack.length - 1];
    const type = state.node.type;
    if (type !== "VariableDeclaration" && type !== "FunctionDeclaration" && !type.endsWith("Statement")) return false;
    if (type === "BlockStatement") return false;
    if (type === "VariableDeclaration" && stack.length > 1 && stack[stack.length - 2].node.type === "ForStatement") return false;
    if (oldStack[oldStack.length - 1] === state) return false;
    if (oldStack.includes(state) && !["ForStatement", "WhileStatement", "DoWhileStatement"].includes(type)) return false;
    oldStack = stack.slice();
    return true;
  };
  const readVariables = () => {
    const values = {};
    const scopes = interpreter.getStateStack().slice().reverse().map(state => state.scope).filter(Boolean);
    scopes.push(interpreter.getGlobalScope());
    variableNames.forEach(name => {
      let found;
      let isFound = false;
      for (const scope of scopes) {
        const object = scope.object || scope;
        const value = interpreter.getProperty(object, name);
        if (value !== undefined) {
          found = value;
          isFound = true;
          break;
        }
      }
      if (!isFound) return;
      if (functionNames.has(name)) {
        values[name] = { __visualValue: true, type: "function", text: "ƒ function" };
      } else if (found && typeof found === "object") {
        const native = (() => {
          try { return interpreter.pseudoToNative(found); }
          catch (error) { return null; }
        })();
        const type = typeof native === "function" ? "function" : Array.isArray(native) ? "array" : "object";
        values[name] = { __visualValue: true, type, text: formatPseudoValue(interpreter, found) };
      } else values[name] = found;
    });
    return values;
  };

  const steps = [];
  let microSteps = 0;
  let outputCount = 0;
  let finished = false;
  while (!finished) {
    let boundaryFound = false;
    while (!boundaryFound && !finished) {
      if (++microSteps > 50000) throw new Error("Execution stopped at the 50,000-operation safety limit.");
      const stack = interpreter.getStateStack();
      if (!stack.length) {
        finished = true;
        break;
      }
      const state = stack[stack.length - 1];
      const boundary = isLine(stack);
      const line = boundary ? getLine(state.node.start) : null;
      let hasMore;
      try {
        hasMore = interpreter.step();
      } catch (error) {
        const errorLine = line || getLine(state.node.start);
        throw new Error(`Line ${errorLine}: ${error.message}`);
      }
      if (boundary) {
        if (steps.length >= 500) throw new Error(`Line ${line}: execution stopped at the 500-step visualization limit.`);
        const step = { line, vars: readVariables(), message: `Executed line ${line} in the JavaScript sandbox.` };
        if (output.length > outputCount) {
          step.output = output.join("\n");
          outputCount = output.length;
        }
        steps.push(step);
        boundaryFound = true;
      }
      if (!hasMore) finished = true;
    }
  }
  if (output.length > outputCount && steps.length) steps[steps.length - 1].output = output.join("\n");
  if (!steps.length) throw new Error("Add a JavaScript statement before running the trace.");
  return { title: "Your code", code: source.replace(/\r/g, "").split("\n"), steps };
}

function renderCode() {
  const lesson = getCurrentLesson();
  editorDirty = false;
  elements.codeInput.value = lesson.code.join("\n");
  elements.fileName.textContent = customLesson ? "your-code.js" : "lesson.js";
  elements.fileLocation.textContent = customLesson ? "/ your workspace" : "/ examples";
  renderCodeLines(lesson.code);
  elements.stepTotal.textContent = String(lesson.steps.length).padStart(2, "0");
}

function renderCodeLines(lines) {
  elements.codeList.innerHTML = lines.map((line, index) =>
    `<div class="code-line" data-line="${index + 1}"><span class="line-number">${String(index + 1).padStart(2, "0")}</span><span class="code-text">${colorize(line)}</span></div>`
  ).join("");
}

function formatValue(value) {
  if (value && value.__visualValue) return value.text;
  if (typeof value === "string") return `"${value}"`;
  return String(value);
}

function valueType(value) {
  if (value && value.__visualValue) return value.type;
  if (typeof value === "string") return "string";
  if (typeof value === "boolean") return "boolean";
  if (typeof value === "number") return "number";
  return typeof value;
}

function renderVariables(values) {
  const names = Object.keys(values);
  elements.memoryCount.textContent = `${names.length} ${names.length === 1 ? "variable" : "in memory"}`;
  if (names.length === 0) {
    elements.variableGrid.innerHTML = '<div class="empty-state"><span class="empty-icon">{ }</span><strong>Nothing in memory yet</strong><span>Take your first step to see variables appear.</span></div>';
    previousValues = {};
    return;
  }
  elements.variableGrid.innerHTML = names.map(name => {
    const updated = Object.prototype.hasOwnProperty.call(previousValues, name) && formatValue(previousValues[name]) !== formatValue(values[name]);
    return `<article class="variable-card${updated ? " is-updated" : ""}"><div class="variable-name-row"><span class="variable-name">${escapeHtml(name)}</span><span class="type-badge">${valueType(values[name])}</span></div><div class="variable-value">${escapeHtml(formatValue(values[name]))}</div></article>`;
  }).join("");
  previousValues = { ...values };
}

function updateControls() {
  const steps = getCurrentLesson().steps;
  elements.previous.disabled = editorDirty || stepIndex === 0;
  elements.next.disabled = editorDirty || stepIndex >= steps.length;
  elements.play.disabled = editorDirty;
  elements.stepCurrent.textContent = String(stepIndex).padStart(2, "0");
  elements.stepTotal.textContent = editorDirty ? "--" : String(steps.length).padStart(2, "0");
  const progress = steps.length ? (stepIndex / steps.length) * 100 : 0;
  elements.progressBar.style.width = `${progress}%`;
  elements.progressLabel.textContent = editorDirty ? "Run your code to start" : stepIndex === 0 ? "Just getting started" : stepIndex === steps.length ? "Lesson complete!" : `${Math.round(progress)}% explored`;
}

function showCurrentStep() {
  if (editorDirty) {
    renderVariables({});
    elements.logicMessage.textContent = "Your code has changed. Run it to build a new execution trace.";
    elements.linePosition.textContent = "UNSAVED CHANGES";
    elements.consoleOutput.innerHTML = '<span class="console-cursor"></span> Run your code to see its output.';
    elements.consoleOutput.classList.remove("has-output");
    elements.consoleState.textContent = "CODE NOT RUN";
    elements.consoleState.classList.remove("is-written");
    updateControls();
    return;
  }
  const lesson = getCurrentLesson();
  const step = stepIndex === 0 ? null : lesson.steps[stepIndex - 1];
  document.querySelectorAll(".code-line").forEach(line => {
    const current = step && Number(line.dataset.line) === step.line;
    line.classList.toggle("is-current", Boolean(current));
    if (current) {
      const top = line.offsetTop;
      const bottom = top + line.offsetHeight;
      if (top < elements.codeScroll.scrollTop || bottom > elements.codeScroll.scrollTop + elements.codeScroll.clientHeight) {
        elements.codeScroll.scrollTo({ top: Math.max(0, top - 75), behavior: "smooth" });
      }
    }
  });
  renderVariables(step ? step.vars : {});
  elements.logicMessage.innerHTML = step ? step.message : 'Press <strong>Next step</strong> and we’ll unpack the code together.';
  elements.linePosition.textContent = step
    ? `LINE ${String(step.line).padStart(2, "0")} / ${String(lesson.code.length).padStart(2, "0")}`
    : customLesson ? "READY TO STEP" : "CLICK TO EDIT";
  const outputStep = lesson.steps.slice(0, stepIndex).reverse().find(item => Object.prototype.hasOwnProperty.call(item, "output"));
  const hasOutput = Boolean(outputStep);
  elements.consoleOutput.classList.toggle("has-output", hasOutput);
  elements.consoleState.classList.toggle("is-written", hasOutput);
  elements.consoleState.textContent = hasOutput ? "1 ITEM WRITTEN" : "AWAITING OUTPUT";
  elements.consoleOutput.innerHTML = hasOutput
    ? `<span class="console-cursor"></span>${escapeHtml(outputStep.output)}`
    : '<span class="console-cursor"></span> Output will appear when the program logs a value.';
  updateControls();
  if (elements.assistantPopover && !elements.assistantPopover.hidden && assistantView === "suggestions") renderSuggestions();
}

function stopPlayback() {
  if (playTimer) {
    window.clearInterval(playTimer);
    playTimer = null;
  }
  elements.play.classList.remove("is-playing");
  elements.play.setAttribute("aria-label", "Play automatic execution");
  elements.play.querySelector("span").textContent = "Auto-run";
}

function advanceStep() {
  const total = getCurrentLesson().steps.length;
  if (stepIndex >= total) {
    stopPlayback();
    updateControls();
    return;
  }
  stepIndex += 1;
  showCurrentStep();
  if (stepIndex >= total) stopPlayback();
}

function togglePlayback() {
  if (playTimer) {
    stopPlayback();
    updateControls();
    return;
  }
  if (editorDirty) return;
  if (stepIndex >= getCurrentLesson().steps.length) stepIndex = 0;
  elements.play.classList.add("is-playing");
  elements.play.setAttribute("aria-label", "Pause automatic execution");
  elements.play.querySelector("span").textContent = "Pause";
  showCurrentStep();
  const interval = 1550 - (Number(elements.speed.value) - 1) * 260;
  playTimer = window.setInterval(advanceStep, interval);
}

function resetExecution() {
  stopPlayback();
  stepIndex = 0;
  showCurrentStep();
}

function selectTopic(topic) {
  if (!Object.prototype.hasOwnProperty.call(lessons, topic)) return;
  stopPlayback();
  activeTopic = topic;
  customLesson = null;
  stepIndex = 0;
  elements.topicButtons.forEach(button => {
    const selected = button.dataset.topic === topic;
    button.classList.toggle("is-active", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
  renderCode();
  showCurrentStep();
  if (!elements.assistantPopover.hidden) {
    assistantView = "suggestions";
    renderSuggestions();
  }
}

function getSuggestions() {
  const lesson = getCurrentLesson();
  const variable = Object.keys(lesson.steps[Math.max(0, stepIndex - 1)].vars)[0] || "variable";
  if (customLesson) {
    return [
      [`Why did ${variable} change?`, "why_var_changed"],
      ["Explain this highlighted line", "explain_line"],
      ["What is this code doing?", "code_overview"]
    ];
  }
  const suggestions = {
    variables: [
      [`Why did ${variable} change?`, "why_var_changed"],
      ["What lives in memory?", "memory_overview"],
      ["Explain this highlighted line", "explain_line"]
    ],
    loops: [
      ["How does this loop work?", "loop_logic"],
      ["Why does sum change?", "why_var_changed"],
      ["When does the loop stop?", "loop_exit"]
    ],
    conditions: [
      ["How does this condition work?", "condition_logic"],
      ["What does || mean?", "operator_explanation"],
      ["Why did this variable change?", "why_var_changed"]
    ],
    functions: [
      ["What happens when we call this function?", "function_call"],
      ["What does return do?", "return_behavior"],
      ["Why did the result change?", "why_var_changed"]
    ]
  };
  return suggestions[activeTopic];
}

function renderSuggestions() {
  assistantView = "suggestions";
  elements.assistantTitle.textContent = "Suggested topics";
  const chips = getSuggestions().map(([label, promptType]) =>
    `<button class="suggestion-chip" type="button" data-prompt-type="${promptType}" data-question="${escapeHtml(label)}"><span>${escapeHtml(label)}</span><span aria-hidden="true">›</span></button>`
  ).join("");
  elements.assistantContent.innerHTML = `<p class="assistant-intro">Ask about this ${getCurrentLesson().title.toLowerCase()} trace, or choose a suggested question.</p><div class="suggestion-list">${chips}</div><form class="custom-question-form" id="custom-question-form"><label for="custom-question">Ask about the highlighted line</label><div class="custom-question-row"><input id="custom-question" name="question" maxlength="240" placeholder="Type a question…" required /><button type="submit" aria-label="Ask the AI tutor">Ask</button></div></form><div id="sphere-explanation-view" class="sphere-explanation-view"></div>`;
  elements.assistantContent.querySelectorAll("[data-prompt-type]").forEach(button => {
    button.addEventListener("click", () => requestSmartExplanation(button.dataset.promptType, button.dataset.question));
  });
  elements.assistantContent.querySelector("#custom-question-form").addEventListener("submit", event => {
    event.preventDefault();
    const input = elements.assistantContent.querySelector("#custom-question");
    const question = input.value.trim();
    if (question) requestSmartExplanation("custom_question", question);
  });
}

function getCustomLessonId(code) {
  let hash = 2166136261;
  for (const character of code.join("\n")) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return 100000 + ((hash >>> 0) % 2147000000);
}

function appendExplanationText(container, text) {
  text.split(/\*\*(.+?)\*\*/g).forEach((part, index) => {
    if (index % 2 === 1) {
      const strong = document.createElement("strong");
      strong.textContent = part;
      container.appendChild(strong);
    } else {
      container.appendChild(document.createTextNode(part));
    }
  });
}

function appendBackButton(container) {
  const backButton = document.createElement("button");
  backButton.className = "back-button";
  backButton.type = "button";
  backButton.textContent = "← Back to suggestions";
  backButton.addEventListener("click", renderSuggestions);
  container.appendChild(backButton);
}

async function requestSmartExplanation(promptType, customQuestion) {
  const view = elements.assistantContent.querySelector("#sphere-explanation-view");
  if (!view) return;
  const lesson = getCurrentLesson();
  const step = stepIndex > 0 ? lesson.steps[stepIndex - 1] : null;
  const lineNumber = step?.line || 1;
  const codeSnippet = lesson.code[lineNumber - 1] || "";
  const lessonIds = { variables: 1, loops: 2, conditions: 3, functions: 4 };
  const lessonId = customLesson ? getCustomLessonId(lesson.code) : lessonIds[activeTopic];
  const currentVariables = step ? step.vars : {};
  assistantView = "explanation";
  elements.assistantTitle.textContent = "Your AI tutor";
  view.classList.remove("is-visible");
  view.innerHTML = '<div class="ai-loading-state" role="status" aria-live="polite"><div class="sphere-ai-thinking-pulse"><span></span></div><p>Reading the current line…</p><div class="ai-skeleton-loader" aria-hidden="true"><i></i><i></i><i></i></div></div>';
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 25000);
  try {
    const response = await fetch("/api/v1/assistant/explain", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        lessonId,
        lineNumber,
        codeSnippet,
        promptType,
        currentVariables,
        userQuestion: customQuestion
      }),
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.success || typeof result.explanation !== "string") {
      throw new Error(result.error || "The AI tutor could not answer right now. Please try again.");
    }
    view.replaceChildren();
    const answer = document.createElement("p");
    answer.className = "ai-explanation-text";
    appendExplanationText(answer, result.explanation);
    const source = document.createElement("span");
    source.className = "ai-source-label";
    source.textContent = result.source === "cache" ? "Saved explanation · instant" : "AI tutor · Gemini";
    view.append(answer, source);
    appendBackButton(view);
    requestAnimationFrame(() => view.classList.add("is-visible"));
  } catch (error) {
    view.replaceChildren();
    const message = document.createElement("p");
    message.className = "ai-error-message";
    message.textContent = error.name === "AbortError"
      ? "The explanation is taking longer than expected. Please try again."
      : error.message || "The AI tutor is unavailable right now. Please try again shortly.";
    view.appendChild(message);
    appendBackButton(view);
    requestAnimationFrame(() => view.classList.add("is-visible"));
  } finally {
    window.clearTimeout(timeoutId);
  }
}

function setAssistantOpen(open) {
  elements.assistantPopover.hidden = !open;
  elements.assistantOrb.setAttribute("aria-expanded", String(open));
  if (open) {
    assistantView = "suggestions";
    renderSuggestions();
  }
}

function runLearnerCode() {
  stopPlayback();
  let lesson;
  try {
    lesson = window.Interpreter
      ? executeWithJavaScriptInterpreter(elements.codeInput.value)
      : executeCustomProgram(elements.codeInput.value);
  } catch (error) {
    showCodeError(error);
    return;
  }
  customLesson = lesson;
  editorDirty = false;
  stepIndex = 0;
  elements.fileName.textContent = "your-code.js";
  elements.fileLocation.textContent = "/ your workspace";
  renderCodeLines(customLesson.code);
  showCurrentStep();
  if (!elements.assistantPopover.hidden) renderSuggestions();
}

function showCodeError(error) {
  customLesson = null;
  editorDirty = true;
  stepIndex = 0;
  renderVariables({});
  elements.logicMessage.textContent = error.message;
  elements.consoleOutput.textContent = error.message;
  elements.consoleOutput.classList.remove("has-output");
  elements.consoleState.textContent = "INPUT ERROR";
  elements.consoleState.classList.remove("is-written");
  const lineMatch = error.message.match(/Line (\d+)/i);
  const errorLine = lineMatch ? Number(lineMatch[1]) : null;
  elements.linePosition.textContent = errorLine ? `ERROR · LINE ${String(errorLine).padStart(2, "0")}` : "CHECK YOUR CODE";
  elements.codeList.querySelectorAll(".code-line").forEach(line => {
    line.classList.toggle("is-error", Number(line.dataset.line) === errorLine);
    line.classList.remove("is-current");
  });
  updateControls();
}

elements.topicButtons.forEach(button => button.addEventListener("click", () => selectTopic(button.dataset.topic)));
elements.next.addEventListener("click", advanceStep);
elements.previous.addEventListener("click", () => {
  if (stepIndex > 0) {
    stopPlayback();
    stepIndex -= 1;
    showCurrentStep();
  }
});
elements.play.addEventListener("click", togglePlayback);
elements.stop.addEventListener("click", resetExecution);
elements.resetCode.addEventListener("click", () => selectTopic(activeTopic));
elements.runCode.addEventListener("click", runLearnerCode);
elements.codeInput.addEventListener("input", () => {
  stopPlayback();
  customLesson = null;
  editorDirty = true;
  stepIndex = 0;
  elements.fileName.textContent = "your-code.js";
  elements.fileLocation.textContent = "/ your workspace";
  renderCodeLines(elements.codeInput.value.replace(/\r/g, "").split("\n"));
  showCurrentStep();
});
elements.codeInput.addEventListener("keydown", event => {
  if (event.key === "Tab") {
    event.preventDefault();
    const start = elements.codeInput.selectionStart;
    const end = elements.codeInput.selectionEnd;
    elements.codeInput.setRangeText("  ", start, end, "end");
    elements.codeInput.dispatchEvent(new Event("input", { bubbles: true }));
  }
});
elements.speed.addEventListener("input", () => {
  if (playTimer) {
    stopPlayback();
    togglePlayback();
  }
});
elements.assistantOrb.addEventListener("click", () => setAssistantOpen(elements.assistantPopover.hidden));
elements.assistantClose.addEventListener("click", () => setAssistantOpen(false));
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && !elements.assistantPopover.hidden) setAssistantOpen(false);
});

renderCode();
showCurrentStep();
